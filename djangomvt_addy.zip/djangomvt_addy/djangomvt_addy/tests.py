from django.urls import reverse
# from django.test import T

from django.test import TestCase

class myTC(TestCase):
    def setUp(self) -> None:
        return super().setUp()
    def test_equal(self):
        self.assertEqual(1 , 1)
    def test_notequal(self):
        self.assertEqual(1 , 2)
    def test3(self):
        response=self.client.get(reverse('myproject'))
        self.assertTrue(response,'failure')